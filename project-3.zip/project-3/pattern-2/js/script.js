
let msg=' ';
let a=1;

for(let i=1;i<=5;i++){

    for(let j=1;j<=i;j++){

        msg+=`${a} `;
        a++;
    }
    msg+='<br>'
}
document.getElementById('msg').innerHTML=msg
