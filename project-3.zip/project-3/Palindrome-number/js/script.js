var num = 151;
var sum = 0;
var temp;
var rum;

temp = num;

while(num != 0){
    rum = num % 10 ;
    sum =(sum * 10) + rum  ;
    num = parseInt(num / 10);
}

if(temp == sum){

    document.getElementById("msg").innerHTML = temp + " is palindrome";
}
else{
    
    document.getElementById("msg").innerHTML = temp + " is not palindrome";
}

