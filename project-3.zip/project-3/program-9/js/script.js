let total = 0;
let i = 0;

do{
    total += i;

    i++;

} while (i <= 30);

document.getElementById("msg").innerHTML = total + " is total sum of integers 0 to 30";