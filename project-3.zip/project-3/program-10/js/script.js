let no = 1;

do {
    if (no % 3 === 0 && no % 5 === 0) {

        document.getElementById("msg").innerHTML += "FizzBuzz" + "<br>";

    } else if (no % 3 === 0) {

        document.getElementById("msg").innerHTML += "Fizz" + "<br>";

    } else if (no % 5 === 0) {

        document.getElementById("msg").innerHTML += "Buzz" + "<br>";
    } else {

        document.getElementById("msg").innerHTML += no + "<br>";
    }

    no++;
} while (no <= 100);
