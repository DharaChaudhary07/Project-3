
let msg=document.getElementById('msg').innerHTML;

for(let i=1; i<=10; i++){

    msg += `${i} `;

}

document.getElementById('msg').innerHTML = msg;