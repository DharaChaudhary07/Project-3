
var sum = 0 ;
var number = 153;
var temp;
var num ;

temp = number;
while (temp > 0) {

    num = temp % 10;
    sum += num * num * num;
   
    temp = parseInt(temp / 10); 
}

if (sum == number) {

    document.getElementById("msg").innerHTML = number +' is Armstrong number.'
    
}
else {

    document.getElementById("msg").innerHTML = number +' is not Armstrong number.'
    
}