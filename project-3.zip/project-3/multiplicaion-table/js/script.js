

let i=1
let table = document.getElementById("table")

while(i <= 10){

    console.log("5" + " x " + i + " = " + 5*i);
    document.getElementById("table").innerHTML += "5" + " x " + i + " = " + 5*i + "<br>";
    i++;
}

