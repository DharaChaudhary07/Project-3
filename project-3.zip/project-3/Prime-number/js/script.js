let n = 3;
let i = 1;
let num = 0;

while(i <= n){

  if(n % i == 0){

      num++;
  }
  i++;

}

if(num == 2){

    document.getElementById("msg").innerHTML = n + " is a prime number";
}
else{
    document.getElementById("msg").innerHTML = n + " is not a prime number";
}