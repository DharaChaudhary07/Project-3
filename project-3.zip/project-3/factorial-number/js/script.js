

let n=5;
let i=1;
let fact=1;
let msg = document.getElementById("msg");

while(i<=n){
    
  fact = fact*i 
  i++
}
console.log(fact);

// document.getElementById("msg").innerHTML = fact;