

let msg = document.getElementById("msg").innerHTML;
let sum = 0;


    for (let i = 1; i * i <= 100; i++) {

        sum += i * i;

    }
document.getElementById("msg").innerHTML = sum;